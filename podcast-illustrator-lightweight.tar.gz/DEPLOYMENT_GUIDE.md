# 🚀 Podcast Illustrator Deployment Guide

This guide will help you deploy the Podcast Illustrator application to production.

## 📋 Prerequisites

- Server with Ubuntu 20.04+ or similar Linux distribution
- Python 3.11+
- Node.js 20+
- FFmpeg installed
- At least 4GB RAM and 20GB storage
- OpenAI API key with sufficient credits

## 🔧 Server Setup

### 1. Install System Dependencies
```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Python and Node.js
sudo apt install python3.11 python3.11-venv python3-pip nodejs npm -y

# Install FFmpeg
sudo apt install ffmpeg -y

# Install pnpm
npm install -g pnpm
```

### 2. Clone and Setup Application
```bash
# Clone the application (or upload your files)
mkdir /opt/podcast-illustrator
cd /opt/podcast-illustrator

# Copy backend files
cp -r /path/to/podcast-illustrator-backend ./backend
cp -r /path/to/podcast-illustrator-frontend ./frontend
```

## 🔨 Backend Deployment

### 1. Setup Python Environment
```bash
cd /opt/podcast-illustrator/backend
python3.11 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Install production server
pip install gunicorn
```

### 2. Create Environment File
```bash
cat > .env << EOF
OPENAI_API_KEY=your_openai_api_key_here
OPENAI_API_BASE=https://api.openai.com/v1
FLASK_ENV=production
UPLOAD_FOLDER=/opt/podcast-illustrator/uploads
EOF
```

### 3. Create Upload Directory
```bash
mkdir -p /opt/podcast-illustrator/uploads
chmod 755 /opt/podcast-illustrator/uploads
```

### 4. Create Systemd Service
```bash
sudo tee /etc/systemd/system/podcast-illustrator-backend.service > /dev/null << EOF
[Unit]
Description=Podcast Illustrator Backend
After=network.target

[Service]
Type=simple
User=www-data
WorkingDirectory=/opt/podcast-illustrator/backend
Environment=PATH=/opt/podcast-illustrator/backend/venv/bin
ExecStart=/opt/podcast-illustrator/backend/venv/bin/gunicorn -w 4 -b 127.0.0.1:5000 src.main:app
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# Enable and start service
sudo systemctl enable podcast-illustrator-backend
sudo systemctl start podcast-illustrator-backend
sudo systemctl status podcast-illustrator-backend
```

## 🎨 Frontend Deployment

### 1. Build Frontend
```bash
cd /opt/podcast-illustrator/frontend
pnpm install
pnpm run build
```

### 2. Setup Nginx
```bash
# Install Nginx
sudo apt install nginx -y

# Create Nginx configuration
sudo tee /etc/nginx/sites-available/podcast-illustrator > /dev/null << EOF
server {
    listen 80;
    server_name your-domain.com;  # Replace with your domain
    
    # Frontend static files
    location / {
        root /opt/podcast-illustrator/frontend/dist;
        try_files \$uri \$uri/ /index.html;
        
        # Security headers
        add_header X-Frame-Options "SAMEORIGIN" always;
        add_header X-XSS-Protection "1; mode=block" always;
        add_header X-Content-Type-Options "nosniff" always;
    }
    
    # Backend API proxy
    location /api/ {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        
        # Increase timeouts for long-running requests
        proxy_connect_timeout 300s;
        proxy_send_timeout 300s;
        proxy_read_timeout 300s;
        
        # Increase max body size for file uploads
        client_max_body_size 100M;
    }
    
    # Static assets caching
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
        root /opt/podcast-illustrator/frontend/dist;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
EOF

# Enable site
sudo ln -s /etc/nginx/sites-available/podcast-illustrator /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

## 🔒 SSL/HTTPS Setup (Optional but Recommended)

### Using Let's Encrypt
```bash
# Install Certbot
sudo apt install certbot python3-certbot-nginx -y

# Get SSL certificate
sudo certbot --nginx -d your-domain.com

# Auto-renewal
sudo systemctl enable certbot.timer
```

## 📊 Monitoring and Logging

### 1. Setup Log Rotation
```bash
sudo tee /etc/logrotate.d/podcast-illustrator > /dev/null << EOF
/opt/podcast-illustrator/backend/logs/*.log {
    daily
    missingok
    rotate 30
    compress
    delaycompress
    notifempty
    create 644 www-data www-data
}
EOF
```

### 2. Monitor Services
```bash
# Check backend status
sudo systemctl status podcast-illustrator-backend

# Check backend logs
sudo journalctl -u podcast-illustrator-backend -f

# Check Nginx status
sudo systemctl status nginx

# Check Nginx logs
sudo tail -f /var/log/nginx/access.log
sudo tail -f /var/log/nginx/error.log
```

## 🔧 Maintenance

### Regular Tasks
```bash
# Update system packages
sudo apt update && sudo apt upgrade -y

# Restart services if needed
sudo systemctl restart podcast-illustrator-backend
sudo systemctl reload nginx

# Clean up old upload files (run weekly)
find /opt/podcast-illustrator/uploads -type f -mtime +7 -delete
```

### Backup Strategy
```bash
# Backup script
#!/bin/bash
BACKUP_DIR="/backup/podcast-illustrator"
DATE=$(date +%Y%m%d_%H%M%S)

mkdir -p $BACKUP_DIR

# Backup application code
tar -czf $BACKUP_DIR/app_$DATE.tar.gz /opt/podcast-illustrator

# Backup recent uploads (last 7 days)
find /opt/podcast-illustrator/uploads -type f -mtime -7 -exec cp {} $BACKUP_DIR/uploads_$DATE/ \;

# Keep only last 30 days of backups
find $BACKUP_DIR -type f -mtime +30 -delete
```

## 🚨 Troubleshooting

### Common Issues

1. **Backend won't start**
   ```bash
   # Check logs
   sudo journalctl -u podcast-illustrator-backend -n 50
   
   # Check Python environment
   cd /opt/podcast-illustrator/backend
   source venv/bin/activate
   python -c "import src.main"
   ```

2. **File upload fails**
   ```bash
   # Check permissions
   ls -la /opt/podcast-illustrator/uploads
   
   # Check Nginx config
   sudo nginx -t
   
   # Check client_max_body_size
   grep -r client_max_body_size /etc/nginx/
   ```

3. **Processing fails**
   ```bash
   # Check OpenAI API key
   cd /opt/podcast-illustrator/backend
   source venv/bin/activate
   python -c "import os; print(os.getenv('OPENAI_API_KEY'))"
   
   # Check FFmpeg
   ffmpeg -version
   ```

4. **High memory usage**
   ```bash
   # Monitor memory
   htop
   
   # Reduce worker processes if needed
   sudo systemctl edit podcast-illustrator-backend
   # Add: ExecStart=/opt/podcast-illustrator/backend/venv/bin/gunicorn -w 2 -b 127.0.0.1:5000 src.main:app
   ```

## 📈 Performance Optimization

### 1. Database (if added later)
- Use PostgreSQL for production
- Set up connection pooling
- Regular maintenance and vacuuming

### 2. Caching
- Add Redis for session storage
- Cache frequently accessed data
- Implement CDN for static assets

### 3. Scaling
- Use multiple worker processes
- Consider load balancing for high traffic
- Implement queue system for processing jobs

## 🔐 Security Checklist

- [ ] Change default passwords and keys
- [ ] Enable firewall (ufw)
- [ ] Regular security updates
- [ ] Monitor access logs
- [ ] Implement rate limiting
- [ ] Use HTTPS only
- [ ] Secure file upload validation
- [ ] Regular backups

## 📞 Support

For deployment issues:
1. Check logs first
2. Verify all dependencies are installed
3. Ensure proper file permissions
4. Test API endpoints manually
5. Monitor system resources

---

**Your Podcast Illustrator application is now ready for production! 🎉**

