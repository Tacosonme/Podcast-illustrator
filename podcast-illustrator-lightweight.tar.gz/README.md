# 🎙️ Podcast Illustrator

Transform your podcast episodes into visually engaging videos with AI-powered illustrations and seamless audio-visual synchronization.

## 🌟 Features

- **Audio Processing**: Upload podcast files in multiple formats (MP3, WAV, M4A, FLAC, OGG)
- **AI Transcription**: Automatic speech-to-text with precise timestamps
- **Content Analysis**: AI analyzes content to identify visual illustration opportunities
- **Visual Generation**: Searches for and generates relevant images using AI
- **Video Composition**: Creates synchronized audio-visual content
- **Real-time Progress**: Live updates throughout the entire process
- **Modern UI**: Responsive React interface with drag-and-drop upload

## 🏗️ Architecture

### Backend (Flask)
- **Audio Processing Service**: Handles file upload, segmentation, and transcription
- **Content Analyzer**: Identifies topics and moments suitable for visual illustration
- **Visual Content Generator**: Searches for and generates relevant images
- **Video Composer**: Combines audio with visual content to create final video
- **RESTful API**: Comprehensive endpoints for all functionality

### Frontend (React)
- **File Upload Interface**: Drag-and-drop with progress tracking
- **Processing Dashboard**: Real-time status updates and progress visualization
- **Content Preview**: Review generated images before video creation
- **Video Player**: Preview final output with playback controls
- **Download System**: Easy access to completed illustrated videos

## 🚀 Quick Start

### Prerequisites
- Python 3.11+
- Node.js 20+
- FFmpeg (for audio/video processing)

### Backend Setup
```bash
cd podcast-illustrator-backend
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
python src/main.py
```

### Frontend Setup
```bash
cd podcast-illustrator-frontend
pnpm install
pnpm run dev --host
```

### Environment Variables
Create a `.env` file in the backend directory:
```env
OPENAI_API_KEY=your_openai_api_key_here
OPENAI_API_BASE=https://api.openai.com/v1
```

## 📖 API Documentation

### Upload Endpoint
```http
POST /api/upload
Content-Type: multipart/form-data

Form Data:
- audio: Audio file (MP3, WAV, M4A, FLAC, OGG)

Response:
{
  "job_id": "uuid",
  "filename": "podcast.mp3",
  "file_size": 79359441,
  "duration": 4959.36,
  "status": "uploaded"
}
```

### Process Endpoint
```http
POST /api/process/{job_id}
Content-Type: application/json

Body:
{
  "segment_duration": 600,
  "generate_images": true,
  "generate_videos": false
}

Response:
{
  "job_id": "uuid",
  "status": "processing",
  "message": "Processing started"
}
```

### Status Endpoint
```http
GET /api/status/{job_id}

Response:
{
  "status": "processing",
  "progress": 45,
  "message": "Transcribing segment 4/9",
  "timestamp": "2025-09-06T12:57:21.603875"
}
```

### Download Endpoint
```http
GET /api/download/{job_id}

Response: Video file (MP4)
```

## 🔧 Configuration

### Audio Processing
- **Segment Duration**: Default 600 seconds (10 minutes) per segment
- **Supported Formats**: MP3, WAV, M4A, FLAC, OGG
- **Maximum File Size**: 100MB (configurable)

### Visual Content
- **Image Generation**: AI-powered image creation for podcast topics
- **Image Search**: Web search for relevant stock images
- **Content Analysis**: AI identifies visual opportunities in transcript

### Video Output
- **Resolution**: 1080p HD
- **Format**: MP4 with H.264 encoding
- **Audio**: Original podcast audio preserved
- **Visuals**: Synchronized image overlays with smooth transitions

## 🛠️ Development

### Project Structure
```
podcast-illustrator/
├── backend/
│   ├── src/
│   │   ├── routes/          # API endpoints
│   │   ├── services/        # Business logic
│   │   ├── models/          # Data models
│   │   └── main.py          # Flask application
│   ├── requirements.txt
│   └── README.md
├── frontend/
│   ├── src/
│   │   ├── components/      # React components
│   │   ├── hooks/           # Custom hooks
│   │   ├── lib/             # Utilities
│   │   └── App.jsx          # Main component
│   ├── package.json
│   └── README.md
└── README.md
```

### Adding New Features
1. **Backend**: Add new routes in `src/routes/` and services in `src/services/`
2. **Frontend**: Create components in `src/components/` and update App.jsx
3. **API**: Update API documentation and add tests

## 🚀 Deployment

### Backend Deployment
```bash
# Using Flask production server
pip install gunicorn
gunicorn -w 4 -b 0.0.0.0:5000 src.main:app
```

### Frontend Deployment
```bash
# Build for production
pnpm run build

# Serve static files
pnpm run preview
```

### Docker Deployment
```dockerfile
# Backend Dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
EXPOSE 5000
CMD ["gunicorn", "-w", "4", "-b", "0.0.0.0:5000", "src.main:app"]
```

## 📊 Performance

- **Processing Speed**: ~2-3x real-time for transcription
- **Image Generation**: 10-30 seconds per image
- **Video Rendering**: 1-2x real-time depending on content length
- **Memory Usage**: ~2GB RAM for typical podcast episodes

## 🐛 Troubleshooting

### Common Issues
1. **Upload Fails**: Check file format and size limits
2. **Processing Stalls**: Verify OpenAI API key and credits
3. **Video Generation Fails**: Ensure FFmpeg is installed
4. **Frontend Not Loading**: Check if backend is running on port 5000

### Logs
- Backend logs: Check Flask console output
- Frontend logs: Check browser developer console
- Processing logs: Located in job directories under `uploads/`

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🙏 Acknowledgments

- OpenAI for Whisper transcription and DALL-E image generation
- React and Flask communities for excellent frameworks
- FFmpeg for audio/video processing capabilities

---

**Built with ❤️ for podcast creators who want to bring their audio content to life with engaging visuals.**

